/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
 class App {
 public static void main(String[] args){
    class Login {
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    public String getUsername() {
        return username;
    }
// setting user name 
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
//checking user name 
    public boolean checkUserName() {
        return username.length() <= 5 && username.contains("_");
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8 && password.matches(".[A-Z].") && password.matches(".\\d.") && password.matches(".[@#$%^&+=].");
    }
//register 
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        } else {
            return "User successfully registered";
        }
    }
//Login
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
//returning login status
    public String returnLoginStatus() {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
    }
    }}}
//PART 2 POE
 class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
 
    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
        String lastThreeLetters = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return firstTwoLetters + ":" + taskNumber + ":" + lastThreeLetters;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Task Duration: " + taskDuration + " hours";
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void main(String[] args) {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks: "));
        int totalHours = 0;

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name: ");
            String taskDescription = JOptionPane.showInputDialog("Enter task description: ");
            while (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                taskDescription = JOptionPane.showInputDialog("Enter task description: ");
            }
            String developerDetails = JOptionPane.showInputDialog("Enter developer details: ");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration: "));
            String taskStatus = getTaskStatus();

            Task task = new Task(taskName, i, taskDescription, developerDetails, taskDuration, taskStatus);
            JOptionPane.showMessageDialog(null, task.printTaskDetails());
            totalHours += task.getTaskDuration();
        }

        JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);
    }
    
    private static String getTaskStatus() {
        String[] options = {"To Do", "Done", "Doing"};
        
        return (String) JOptionPane.showInputDialog(null, "Select task status: ", "Task Status", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
    }
 
    }}
 
//POE PART3


 class Main {
//ARRAYS TO STORE TASK DETAILS
    String[] developers = new String[4];
    String[] taskNames = new String[4];
    int[] taskIDs = new int[4];
    int[] taskDurations = new int[4];
    String[] taskStatus = new String[4];

    public static void main(String[] args) {
        Main app = new Main();
        app.mainMenu();
    }

    public void mainMenu() {
        JOptionPane.showMessageDialog(null, "Welcome to the Task Management System");
        developers[0] = "Mike Smith";
        taskNames[0] = "Create Login";
        taskIDs[0] = 1;
        taskDurations[0] = 5;
        taskStatus[0] = "To Do";

        developers[1] = "Edward Harrison";
        taskNames[1] = "Create Add Features";
        taskIDs[1] = 2;
        taskDurations[1] = 8;
        taskStatus[1] = "Doing";

        developers[2] = "Samantha Paulson";
        taskNames[2] = "Create Reports";
        taskIDs[2] = 3;
        taskDurations[2] = 2;
        taskStatus[2] = "Done";

        developers[3] = "Glenda Oberholzer";
        taskNames[3] = "Add Arrays";
        taskIDs[3] = 4;
        taskDurations[3] = 11;
        taskStatus[3] = "To Do";

        int option = JOptionPane.showOptionDialog(null, "Choose an option", "Main Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{"Display Tasks with Status 'Done'", "Display Developer and Duration for Task with Longest Duration", "Search for Task by Name", "Search for Tasks Assigned to Developer", "Delete Task", "Display Report"}, null);

        switch (option) {
            case 0:
                displayTasksWithStatusDone();
                break;
            case 1:
                displayDeveloperAndDurationForTaskWithLongestDuration();
                break;
            case 2:
                searchForTaskByName();
                break;
            case 3:
                searchForTasksAssignedToDeveloper();
                break;
            case 4:
                deleteTask();
                break;
            case 5:
                displayReport();
                break;
        }
    }
//POPULATING ARRAYS TO STORE TASK DETAILS
    public void displayTasksWithStatusDone() {
        String result = "";
        for (int i = 0; i < developers.length; i++) {
            if (taskStatus[i].equals("Done")) {
                result += developers[i] + ", Task Name: " + taskNames[i] + ", Duration: " + taskDurations[i] + "\n";
            }
        }
        JOptionPane.showMessageDialog(null, result);
    }

    public void displayDeveloperAndDurationForTaskWithLongestDuration() {
        int maxDuration = 0;
        int index = -1;
        for (int i = 0; i < taskDurations.length; i++) {
            if (taskDurations[i] > maxDuration) {
                maxDuration = taskDurations[i];
                index = i;
            }
        }
        if (index != -1) {
            JOptionPane.showMessageDialog(null, developers[index] + ", Duration: " + taskDurations[index]);
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found");
        }
    }

    public void searchForTaskByName() {
        String name = JOptionPane.showInputDialog(null, "Enter Task Name");
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(name)) {
                JOptionPane.showMessageDialog(null, developers[i] + ", Task Name: " + name + ", Status: " + taskStatus[i]);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }

    public void searchForTasksAssignedToDeveloper() {
        String name = JOptionPane.showInputDialog(null, "Enter Developer Name");
        String result = "";
        for (int i = 0; i < developers.length; i++) {
            if (developers[i].equals(name)) {
                result += taskNames[i] + "\n";
            }
        }
        if (!result.isEmpty()) {
            JOptionPane.showMessageDialog(null, result);
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found for this developer");
        }
    }

    public void deleteTask() {
        String name = JOptionPane.showInputDialog(null, "Enter Task Name");
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(name)) {
                JOptionPane.showMessageDialog(null, "Entry '" + name + "' successfully deleted");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }

    public void displayReport() {
        StringBuilder report = new StringBuilder();
        report.append("Task ID\tDeveloper\tTask Name\tDuration\tStatus\n");
        for (int i = 0; i < developers.length; i++) {
            report.append(taskIDs[i]).append("\t").append(developers[i]).append("\t").append(taskNames[i]).append("\t").append(taskDurations[i]).append("\t").append(taskStatus[i]).append("\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
        
    }}